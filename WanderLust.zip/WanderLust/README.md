
# Project-Wanderlust

 This project was created from local system
 It's a Full Stack Project based on MERN Development.  This project buliding idea is to list the hotels of different cities globally so that it can easily accessible to    
 your vacation place.
 
#  Frontend:
 HTML5 / CSS3 / JAVA SCRIPT

# Backend:
1. NODE.JS
2. EXPRESS.JS

# Database:
1. MONGO-DB

# Framework
1. BOOTSTRAP

# Other
  This project also have implemented with  MVC Freamwork / REST API'S / AJAX / 

  



